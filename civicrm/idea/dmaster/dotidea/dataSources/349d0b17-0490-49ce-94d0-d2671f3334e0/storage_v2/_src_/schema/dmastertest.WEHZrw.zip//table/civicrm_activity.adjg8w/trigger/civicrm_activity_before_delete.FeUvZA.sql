create definer = dmastercivicrm@`%` trigger civicrm_activity_before_delete
    before delete
    on civicrm_activity
    for each row
BEGIN  
UPDATE civicrm_case SET modified_date = CURRENT_TIMESTAMP WHERE id IN (SELECT ca.case_id FROM civicrm_case_activity ca WHERE ca.activity_id = OLD.id);
 END;

