create definer = dmastercivicrm@`%` trigger civicrm_activity_before_insert
    before insert
    on civicrm_activity
    for each row
BEGIN  
SET NEW.created_date = CURRENT_TIMESTAMP;
 END;

