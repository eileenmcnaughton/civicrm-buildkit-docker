create definer = dmastercivicrm@`%` trigger civicrm_case_before_insert
    before insert
    on civicrm_case
    for each row
BEGIN  
SET NEW.created_date = CURRENT_TIMESTAMP;
 END;

