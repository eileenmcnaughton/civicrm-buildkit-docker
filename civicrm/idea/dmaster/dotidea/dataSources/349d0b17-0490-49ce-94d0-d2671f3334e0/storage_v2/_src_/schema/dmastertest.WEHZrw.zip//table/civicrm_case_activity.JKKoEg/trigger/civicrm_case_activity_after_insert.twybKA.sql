create definer = dmastercivicrm@`%` trigger civicrm_case_activity_after_insert
    after insert
    on civicrm_case_activity
    for each row
BEGIN  
UPDATE civicrm_case SET modified_date = CURRENT_TIMESTAMP WHERE id = NEW.case_id;
 END;

