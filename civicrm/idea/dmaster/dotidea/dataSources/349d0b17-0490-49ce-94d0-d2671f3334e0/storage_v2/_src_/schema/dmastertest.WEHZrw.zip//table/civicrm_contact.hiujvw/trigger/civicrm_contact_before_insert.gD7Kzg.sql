create definer = dmastercivicrm@`%` trigger civicrm_contact_before_insert
    before insert
    on civicrm_contact
    for each row
BEGIN  
SET NEW.created_date = CURRENT_TIMESTAMP;
 END;

