create definer = dmastercivicrm@`%` trigger civicrm_im_after_update
    after update
    on civicrm_im
    for each row
BEGIN  
UPDATE civicrm_contact SET modified_date = CURRENT_TIMESTAMP WHERE id = NEW.contact_id;
 END;

