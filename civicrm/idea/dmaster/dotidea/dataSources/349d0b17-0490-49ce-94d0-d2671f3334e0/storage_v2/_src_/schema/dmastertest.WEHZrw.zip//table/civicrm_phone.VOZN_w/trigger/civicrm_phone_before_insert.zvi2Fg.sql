create definer = dmastercivicrm@`%` trigger civicrm_phone_before_insert
    before insert
    on civicrm_phone
    for each row
BEGIN  
SET NEW.phone_numeric = civicrm_strip_non_numeric(NEW.phone);
 END;

