create definer = dmastercivicrm@`%` trigger civicrm_relationship_after_update
    after update
    on civicrm_relationship
    for each row
BEGIN  INSERT INTO civicrm_relationship_cache (relationship_id, relationship_type_id, orientation, near_contact_id, near_relation, far_contact_id, far_relation, start_date, end_date, is_active)
SELECT rel.id, rel.relationship_type_id, "a_b", rel.contact_id_a, reltype.name_a_b, rel.contact_id_b, reltype.name_b_a, rel.start_date, rel.end_date, rel.is_active
FROM civicrm_relationship rel
INNER JOIN civicrm_relationship_type reltype ON rel.relationship_type_id = reltype.id
WHERE (rel.id = NEW.id)
 ON DUPLICATE KEY UPDATE relationship_type_id = rel.relationship_type_id, near_contact_id = rel.contact_id_a, near_relation = reltype.name_a_b, far_contact_id = rel.contact_id_b, far_relation = reltype.name_b_a, start_date = rel.start_date, end_date = rel.end_date, is_active = rel.is_active
;

INSERT INTO civicrm_relationship_cache (relationship_id, relationship_type_id, orientation, near_contact_id, near_relation, far_contact_id, far_relation, start_date, end_date, is_active)
SELECT rel.id, rel.relationship_type_id, "b_a", rel.contact_id_b, reltype.name_b_a, rel.contact_id_a, reltype.name_a_b, rel.start_date, rel.end_date, rel.is_active
FROM civicrm_relationship rel
INNER JOIN civicrm_relationship_type reltype ON rel.relationship_type_id = reltype.id
WHERE (rel.id = NEW.id)
 ON DUPLICATE KEY UPDATE relationship_type_id = rel.relationship_type_id, near_contact_id = rel.contact_id_b, near_relation = reltype.name_b_a, far_contact_id = rel.contact_id_a, far_relation = reltype.name_a_b, start_date = rel.start_date, end_date = rel.end_date, is_active = rel.is_active
;
 END;

