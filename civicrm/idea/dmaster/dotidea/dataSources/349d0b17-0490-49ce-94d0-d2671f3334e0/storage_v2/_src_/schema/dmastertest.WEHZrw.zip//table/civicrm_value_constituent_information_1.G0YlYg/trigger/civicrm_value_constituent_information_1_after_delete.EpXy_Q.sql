create definer = dmastercivicrm@`%` trigger civicrm_value_constituent_information_1_after_delete
    after delete
    on civicrm_value_constituent_information_1
    for each row
BEGIN  
UPDATE civicrm_contact SET modified_date = CURRENT_TIMESTAMP WHERE id = OLD.entity_id;
 END;

