create definer = dmastercivicrm@`%` trigger civicrm_value_constituent_information_1_after_insert
    after insert
    on civicrm_value_constituent_information_1
    for each row
BEGIN  
UPDATE civicrm_contact SET modified_date = CURRENT_TIMESTAMP WHERE id = NEW.entity_id;
 END;

