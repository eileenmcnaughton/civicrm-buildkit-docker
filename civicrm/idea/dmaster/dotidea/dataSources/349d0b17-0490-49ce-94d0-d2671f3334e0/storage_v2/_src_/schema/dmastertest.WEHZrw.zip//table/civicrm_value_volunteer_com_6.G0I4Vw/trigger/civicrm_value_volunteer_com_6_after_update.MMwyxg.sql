create definer = dmastercivicrm@`%` trigger civicrm_value_volunteer_com_6_after_update
    after update
    on civicrm_value_volunteer_com_6
    for each row
BEGIN  
UPDATE civicrm_activity SET modified_date = CURRENT_TIMESTAMP WHERE id = NEW.entity_id;
 END;

