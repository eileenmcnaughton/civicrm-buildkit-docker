create definer = dmastercivicrm@`%` trigger civicrm_value_volunteer_inf_5_after_insert
    after insert
    on civicrm_value_volunteer_inf_5
    for each row
BEGIN  
UPDATE civicrm_contact SET modified_date = CURRENT_TIMESTAMP WHERE id = NEW.entity_id;
 END;

