create definer = dmastercivicrm@`%` trigger civicrm_website_after_update
    after update
    on civicrm_website
    for each row
BEGIN  
UPDATE civicrm_contact SET modified_date = CURRENT_TIMESTAMP WHERE id = NEW.contact_id;
 END;

